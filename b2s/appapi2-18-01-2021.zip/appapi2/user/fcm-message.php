<?php

$icon="http://kamakhyaits.com/admin/images/logo.png";
$welcomecode="1101";
$welcometitle="You have received a new message, لديك تنبيه جديد ";
$welcomebody="Welcome To Salatcom, مرحبا بكم في تطبيق سلتكم ";

 
$createoredrcode="1102";
$createoredrtitle="Order created, تم انشاء الطلب";
$createoredrbody="Your Order is created. please check your order status in profile section,تم انشاء الطاب ، يرجى متابعة الطلب من قسم الطلبات في حسابك";

$vendercreateoredrcode="1103";
$vendercreateoredrtitle="Your have got a new order, لديك طلب جديد";
$vendercreateoredrbody="Your have got a new order,لديك طلب جديد";


$paymentcode="1104";
$paymenttitle="Order Payment, عملية الدفع";
$paymentbody="Your order payment successfully done,تم اكمال عملية الدفع بنجاح";

$paymenttitlecash="Order Payment Cash on Delivery,الدفع عند التوصيل";
$paymentbodycash="Your order cash on delivery,عملية الدفع عند التوصيل";


$venderpaymentcode="1104";
$venderpaymenttitle="Order Payment,حالة الدفع";
$venderpaymentbody="Your order payment Paid,تم الدفع";
?>