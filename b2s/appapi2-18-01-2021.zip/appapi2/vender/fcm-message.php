<?php

$icon="http://kamakhyaits.com/admin/images/logo.png";
$welcomecode="1101";
$welcometitle="You have received a new message";
$welcomebody="Welcome To Salatcom,مرحبا بكم في تطبيق سلتكم ";

 
$accpetoredrcode="1102";
$accpetoredrtitle="Order ";
$accpetoredrbody="طلبك هو ";
$accpetoredrbody1="please check your order status in profile section, يرجى متابعة حالة الطلب من قسم حسابك";

?>