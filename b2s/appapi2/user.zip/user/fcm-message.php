<?php

$icon="http://kamakhyaits.com/admin/images/logo.png";
$welcomecode="1101";
$welcometitle="You have received a new message";
$welcomebody="Welcome To Salatcom";

 
$createoredrcode="1102";
$createoredrtitle="Order created";
$createoredrbody="Your Order is created. please check your order status in profile section";

$vendercreateoredrcode="1103";
$vendercreateoredrtitle="Your have got a new order";
$vendercreateoredrbody="Your have got a new order";


$paymentcode="1104";
$paymenttitle="Order Payment";
$paymentbody="Your order payment successfully done";

$paymenttitlecash="Order Payment Cash on Delivery";
$paymentbodycash="Your order cash on delivery";


$venderpaymentcode="1104";
$venderpaymenttitle="Order Payment";
$venderpaymentbody="Your order payment Paid";
?>